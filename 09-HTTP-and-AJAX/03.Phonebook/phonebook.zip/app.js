function attachEvents() {
    
const url = 'http://localhost:3030/jsonstore/phonebook';

const phonebook = document.getElementById('phonebook');
const loadButton = document.getElementById('btnLoad');
const createButton = document.getElementById('btnCreate');
const personInput = document.getElementById('person');
const phoneInput = document.getElementById('phone');

loadButton.addEventListener('click', loadPhonebook);
createButton.addEventListener('click', createContact);

async function loadPhonebook() {
    const response = await fetch(url);
    const data = await response.json();

    phonebook.innerHTML = '';

    for (const key in data) {
        const contact = data[key];

        const li = document.createElement('li');
        li.textContent = `${contact.person}: ${contact.phone} `;

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';

        deleteButton.addEventListener('click', async () => {
            await fetch(`${url}/${key}`, {
                method: 'DELETE'
            });

            li.remove();
        });

        li.appendChild(deleteButton);
        phonebook.appendChild(li);
    }
}

async function createContact() {
    const person = personInput.value;
    const phone = phoneInput.value;

    await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            person: person,
            phone: phone
        })
    });

    personInput.value = '';
    phoneInput.value = '';

    await loadPhonebook();
}
}

attachEvents();